import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import Dashboard from './pages/Dashboard';
import Elevators from './pages/Elevators';
import TVs from './pages/TVs';
import CalendarPage from './pages/Calendar';
import Clients from './pages/Clients';
import DebugSupabase from './pages/DebugSupabase';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="clients" element={<Clients />} />
          <Route path="elevators" element={<Elevators />} />
          <Route path="tvs" element={<TVs />} />
          <Route path="calendar" element={<CalendarPage />} />
          <Route path="debug" element={<DebugSupabase />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
